#pragma once

#include "ThostFtdcMdApi.h"
#include <map>
#include <string>
using std::map;
using std::string;

class MarketQutationSpi : public CThostFtdcMdSpi
{
public:
	MarketQutationSpi(CThostFtdcMdApi *mdapi);
	//��������ʱ����
	void OnFrontConnected();
	//�Ͽ�����ʱ����
	void OnFrontDisconnected();
	///��¼������Ӧ
	void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo,
		int nRequestID, bool bIsLast);
	///�ǳ�������Ӧ
	void OnRspUserLogout(CThostFtdcUserLogoutField *pUserLogout, CThostFtdcRspInfoField *pRspInfo,
		int nRequestID, bool bIsLast);
	///��������Ӧ��
	void OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo,
		int nRequestID, bool bIsLast);
	///ȡ����������Ӧ��
	void OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, 
		int nRequestID, bool bIsLast);
	///�������֪ͨ
	void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData);

	void SetBrokerID(string brokerID);
	void SetUserID(string userID);
	void SetPassword(string pwd);
	void SetLoginRequestID(int id);
	void SetContractList(char **contractList, int conctractCount);
	~MarketQutationSpi(void);

private:
	CThostFtdcMdApi *mdapi;
	CThostFtdcReqUserLoginField *loginField;
	string m_brokerID;
	string m_userID;
	string m_pwd;
	int m_loginRequestID;
	int m_contractCount;
	char **m_contractList;
};

