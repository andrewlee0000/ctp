#include "stdafx.h"
#include "Common.h"


Common::Object_Creator Common::_object_creator;

void Common::BuildContractList()
{
	m_contractCount = 3;
	m_contractList = new char*[m_contractCount];

	for(int i=0;i<m_contractCount;i++)
	{
		m_contractList[i] = new char[50];
	}

	m_contractList[0] = "IF1509";
	m_contractList[1] = "IH1509";
	m_contractList[2] = "IC1509";

}

int Common::GetContractCount()
{
	return m_contractCount;
}

char **Common::GetContractList()
{
	return m_contractList;
}
