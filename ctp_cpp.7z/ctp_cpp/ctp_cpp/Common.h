#pragma once
class Common
{
public:
	 static Common *GetInstance()
    {
        static Common instance;
        return &instance;
    }

	void BuildContractList();
	int GetContractCount();
	char **GetContractList();

protected:
    struct Object_Creator
    {
        Object_Creator()
        {
            Common::GetInstance();
        }
    };
    static Object_Creator _object_creator;

    Common() 
	{
		m_contractCount = 0;
	}
    
	~Common() 
	{
		for(int i=0;i<m_contractCount;i++)
		{
			delete []  m_contractList[i];
		}
		delete [] m_contractList; 
	}

private:
	int m_contractCount;
	char **m_contractList;

};
